﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class Attack
    {
        public string title;
        public double range;
        public int damage;
        public bool physical;
    }
}
