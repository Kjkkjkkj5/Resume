﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class Character
    {
        public string CharacterName;
        public int HP;
        public int Mvmt;
        public int MP;
        public int SP;
        public int ArmorClass;
        public int Level;
        public int Potions;
        public Attack Attack1 = new Attack();
        public Attack Attack2 = new Attack();
        


        public Character()
        {
            /*
             * HP and MP and SP
             * High- 150
             * High-Medium-125
             * Medium- 100
             * Medium-Low- 75
             * Low-50
             * None-0
             * 
             * Movement
             * High- 15
             * High-Medium-13
             * Medium- 10
             * Medium-Low- 8
             * Low-5
             * 
             * Armor
             * High- 15
             * High-Medium-13
             * Medium- 10
             * Medium-Low- 8
             * Low-5
             * None-0
             * 
             * Level altering
             * HP and MP and SP
             * +10 each for every level
             * Movement
             * Stamina/10
             * must be int because it would round it
             * Armor
             * goes up 4 every 2 levels
             */
            
           


        }
        public  int TankLevel(int HP, int level) {
            HP = level * 15;
            return HP;
        }
        public  int WizLevel(int MP, int level) {
            MP = level * 15;
            return MP; }
        public int RunnerLevel(int SP, int level) {
            SP = level * 15;
            return SP; }
        public int GeneralLevel( int Stat, int level) {
            Stat = level * 10;
            return Stat; }
        public int WeakArmor(int Armor, int level)
        {
            Armor=level/6*4;
            return Armor;
        }
        public int MediumArmor(int Armor, int level)
        {
            Armor = level / 2 * 4;
            return Armor;
        }
        public int HighArmor(int Armor, int level)
        {
            Armor = level / 2 * 6;
            return Armor;
        }
        public int AttackLevel(int damage, int level)
        {
            damage = level * 6;
            return damage;
        }
    }
}
