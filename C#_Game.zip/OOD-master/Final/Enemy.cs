﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final
{
    class Enemy : Character
    {
        
        //Difficulty Modifer
        public int DM;// -5
        // 3
        // 6
        //12
        //24
        //Difficulty Modifiers
        public string type;
        
        public Enemy()
        {

        }

        public int TankLevel(int HP, int level, int DM)
        {
            HP = (level+DM) * 15;
            return HP;
        }
        public int WizLevel(int MP, int level, int DM)
        {
            MP = (level+DM) * 15;
            return MP;
        }
        public int RunnerLevel(int SP, int level, int DM)
        {
            SP = (level+DM) * 15;
            return SP;
        }
        public int GeneralLevel(int Stat, int level, int DM)
        {
            Stat = (level+DM) * 10;
            return Stat;
        }
        public int WeakArmor(int Armor, int level, int DM)
        {
            Armor = (level+DM) / 6 * 4;
            return Armor;
        }
        public int MediumArmor(int Armor, int level, int DM)
        {
            Armor = (level+DM) / 2 * 4;
            return Armor;
        }
        public int HighArmor(int Armor, int level, int DM)
        {
            Armor = (level+DM) / 2 * 6;
            return Armor;
        }
        public int AttackLevel(int damage, int level, int DM)
        {
            damage = 5 * (level + DM);
            return damage;
        }
    }
}
