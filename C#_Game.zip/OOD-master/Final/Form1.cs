﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Final
{
    public partial class OOD : Form
    {
        //DO NOT REMOVE
        public OOD()
        {
            InitializeComponent();
        }
        Character player = new Character();
        Enemy villian = new Enemy();
        int[] CharLocA = new int[2] {0,0 };
        int[] EnemyLocA = new int[2] { 20, 20 };
        public int HPHolder=0;
        public int MPHolder=0;
        public int SPHolder=0;
        int countdown;
        //DO NOT REMOVE
        //Writes out class descriptions

        private void Form1_Load(object sender, EventArgs e)
        {
            CharacterName.Focus();
            EnemySelect.Visible = false;
            EnemyDifficulty.Visible = false;
            EnemyLabel.Visible = false;
            DiffLabel.Visible = false;

        }

        private void ClassSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            string barb="Barbarian";
            string wiz= "Wizard";
            string arch= "Archer";
            string swords = "Swordsmen";

            if (ClassSelect.Text.Contains(barb))
            {
                ActivityLog.Text += "You selected Barbarian .\n It's time to get up close and personal. With a high armor class who cares about magic.\n\n"; 
                //They have medium health, medium movement, low mana, high armor, and medium stamina
            }
            else if (ClassSelect.Text.Contains(wiz))
            {
                ActivityLog.Text += "You selected Wizard.\n Intelligence rules. Who needs armor when you have trained your brain to take a beating. \n\n";
                //They have medium - high health, medium movement, high mana, no armor, and low stamina.
            }
            else if (ClassSelect.Text.Contains(arch))
            {
                ActivityLog.Text += "You selected Archer.\n Dance around combat. Stay away and stay alive. \n\n";
                //They have low health, high movement, low mana, light armor, and high stamina.
            }
            else if (ClassSelect.Text.Contains(swords))
            {
                ActivityLog.Text += "You selected Swordsmen.\n Let's slice and dice. Get up close and mince the enemy. \n\n";
                //They have medium health, high movement, low mana, medium armor, and high stamina.
            }
        }

        // Writes out descriptions of enemies
        private void EnemySelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            string drag = "Dragon";
            string wl = "Warlock";
            string gl = "Goblin Leader";
            string serp = "Serpant";
            string bandit = "Bandit";
            string gc = "Gelatinous Cube";

            if (EnemySelect.Text.Contains(drag)) { ActivityLog.Text += "You've selected Dragon.\n The most fearsome creature of the medieval world.....besides the plague of course.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemySelect.Text.Contains(wl)) { ActivityLog.Text += "You've selected Warlock.\n The most cruel of the medieval villians. From stealing princesses to turning warriors into chickens and feeding them to the village.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemySelect.Text.Contains(gl)) { ActivityLog.Text += "You've selected Goblin Leader.\n The most common of the medieval villians. Better win or your convoy is getting pillaged and burned to the ground.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemySelect.Text.Contains(serp)) { ActivityLog.Text += "Youve selected Serpant. \nThe bane of sailors for centuries. Get ready for poison damage.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemySelect.Text.Contains(bandit)) { ActivityLog.Text += "You've selected Bandit. \nHow most heros start out; killing bandits for jarls and growing up to be known all over the country.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemySelect.Text.Contains(gc)) { ActivityLog.Text += "You've selected Gelatinous Cube. \nIf you die here your headstone will read Here Lies a Wuse who got killed by living Jell-o. So you better win.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
        }

        //Describes Difficultes
        private void EnemyDifficulty_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
             * Easy
             * Intermediate
             * Hard
             * Impossible
             * Good Luck
             */
            string E = "Easy";
            string I = "Intermediate";
            string H = "Hard";
            string Imp = "Impossible";
            string GL = "Good Luck";
            if (EnemyDifficulty.Text.Contains(E)) { ActivityLog.Text += "Fair choice.......FOR A NOOB\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemyDifficulty.Text.Contains(I)) { ActivityLog.Text += "Better choice but you will never overthrow the empire playing on intermediate.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemyDifficulty.Text.Contains(H)) { ActivityLog.Text += "Finally you are actually trying.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemyDifficulty.Text.Contains(Imp)) { ActivityLog.Text += "Now things are getting out of hand but that's your choice.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            else if (EnemyDifficulty.Text.Contains(GL)) { ActivityLog.Text += "There's a reason this difficulty is called Good Luck......\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }



        }

        public void SuperButton_Click(object sender, EventArgs e) 
        {
            int classNum;
            int level = Convert.ToInt32(LevelControl.Value);
            
            //ActivityLog.Text += "SuperButton Click.\n";
            if (SuperButton.Text.Contains("Create Character"))
            {
                
                if (CharacterName.Text.Length != 0)
                {
                    if (ClassSelect.Text.Contains("Swordsmen") || ClassSelect.Text.Contains("Barbarian") || ClassSelect.Text.Contains("Wizard") || ClassSelect.Text.Contains("Archer"))
                    {
                        
                        if (ClassSelect.Text.Contains("Barbarian")) { classNum = 1; player.Level = level; player =StatSetter(player, classNum); }
                        else if (ClassSelect.Text.Contains("Wizard")) { classNum = 2; player.Level = level; player =StatSetter(player, classNum); }
                        else if (ClassSelect.Text.Contains("Archer")) { classNum = 3; player.Level = level; player =StatSetter(player, classNum); }
                        else if (ClassSelect.Text.Contains("Swordsmen")) { classNum = 4; player.Level = level; player =StatSetter(player, classNum); }
                        else { ActivityLog.Text += "I broke Nested Ifs Character Select.\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        Level.Enabled = false;
                        SuperButton.Text = "Enemy Select";
                        EnemySelect.Visible = true;
                        EnemyDifficulty.Visible = true;
                        EnemyLabel.Visible = true;
                        DiffLabel.Visible = true;
                    }
                    else { ActivityLog.Text += "Please select a class and try again.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; ClassSelect.Focus(); }
                }
                else if (CharacterName.Text.Length == 0) { ActivityLog.Text += "Please enter a name for your character and try again.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; CharacterName.Focus(); }
            }
            else if((SuperButton.Text.Contains("Enemy Select")))
            {
                EnemySelect.Visible = true;
                EnemyDifficulty.Visible = true;
                if( EnemySelect.Text.Contains("Dragon")|| EnemySelect.Text.Contains("Warlock")|| EnemySelect.Text.Contains("Goblin Leader")|| EnemySelect.Text.Contains("Serpant")|| EnemySelect.Text.Contains("Bandit") || EnemySelect.Text.Contains("Gelatinous Cube"))
                {
                    if (EnemyDifficulty.Text.Contains("Easy") || EnemyDifficulty.Text.Contains("Intermediate") || EnemyDifficulty.Text.Contains("Hard") || EnemyDifficulty.Text.Contains("Impossible") || EnemyDifficulty.Text.Contains("Good Luck"))
                        {
                        
                        EnemySelect.Enabled = false;
                        EnemyDifficulty.Enabled = false;
                        if (EnemySelect.Text.Contains("Dragon")) { villian.Level = level; villian.type = EnemySelect.Text; ActivityLog.Text += "Enemy creation successful.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        else if (EnemySelect.Text.Contains("Warlock")) { villian.Level = level; villian.type = EnemySelect.Text; ActivityLog.Text += "Enemy creation successful.\n\n"; }
                        else if (EnemySelect.Text.Contains("Goblin Leader")) { villian.Level = level; villian.type = EnemySelect.Text; ActivityLog.Text += "Enemy creation successful.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        else if (EnemySelect.Text.Contains("Serpant")) { villian.Level = level; villian.type = EnemySelect.Text; ActivityLog.Text += "Enemy creation successful.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        else if (EnemySelect.Text.Contains("Bandit")) { villian.Level = level; villian.type = EnemySelect.Text; ActivityLog.Text += "Enemy creation successful.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        else if (EnemySelect.Text.Contains("Gelatinous Cube")) { villian.Level = level; villian.type = EnemySelect.Text; ActivityLog.Text += "Enemy creation successful.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        else { ActivityLog.Text += "I broke Enemy Maker.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                        
                        ActivityLog.Text += "To your left you see two boxes. Labeled Vertical and Horizontal Movement. " +
                            "You start in the bottom left hand corner at location 0,0. The Enemy starts in the top right hand corner at 20,20. Enter the AMOUNT of squares you would like to move in the corresponding direction." +
                            "FOR EXAMPLE: If you in the starting location and you have five movement you can move 5 places down and none to the side or " +
                            "you could move 3 squares down and two places to the right.\n If nothing is put in the boxes they will default to zero.\n\n";
                        ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        SuperButton.Enabled= false;
                        SuperButton.Visible = false;
                        AlphaButton.Enabled = true;
                        AlphaButton.Visible = true;
                        Horizontal.Enabled = true;
                        Horizontal.Visible = true;
                        Vertical.Enabled = true;
                        Vertical.Visible = true;
                        Hori.Visible= true;
                        Vert.Visible = true;
                        if (EnemyLocA[0] == 20 && EnemyLocA[1] == 20)
                        {
                            EnemySet();
                        }

                    }

                    else { ActivityLog.Text += "Please select a difficulty and try again.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; EnemyDifficulty.Focus(); }
                }
                else { ActivityLog.Text += "Please select an enemy and try again.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; EnemySelect.Focus(); }
            }
            
        }

        private void AlphaButton_Click(object sender, EventArgs e)
        {

            int distance;
            int verticalDis= (EnemyLocA[1] - CharLocA[1]);
            int horizontalDis= (EnemyLocA[0] - CharLocA[0]);
            int MoveH;
            int MoveV;
            int OFBH;
            int OFBV;
            bool continueVariable=false;
            if (AlphaButton.Text.Contains("Move")||AlphaButton.Text.Contains("Stay"))
            {
                //Stupid blocks
                //fixes empty boxes and if anything besides numbers was entered
                if (AlphaButton.Text.Contains("Stay")) {
                    verticalDis = (EnemyLocA[1] - CharLocA[1]);
                    horizontalDis = (EnemyLocA[0] - CharLocA[0]);
                    distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horizontalDis * horizontalDis) + (verticalDis * verticalDis))));
                    ActivityLog.Text += "You didn't move. Your location is still (" + CharLocA[0] + "," + CharLocA[1] + ")\n\n";
                    ActivityLog.Text += "Distance is: " + distance + " \n\n";
                    ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    continueVariable = true;

                }
                if(Vertical.Text.Length == 0 )
                { Vertical.Text = "0"; }
                if (Horizontal.Text.Length == 0)
                { Horizontal.Text = "0"; }
                Vertical.Text = Regex.Replace(Vertical.Text, "[^0-9-]", "");
                Horizontal.Text = Regex.Replace(Horizontal.Text, "[^0-9-]", "");
                MoveH = Convert.ToInt32(Horizontal.Text);
                MoveV = Convert.ToInt32(Vertical.Text);
                OFBH = CharLocA[0] + MoveH;//Here to stop people from moving out of bounds
                OFBV = CharLocA[1] + MoveV;//Here to stop people from moving out of bounds
                if (player.Mvmt>=(Math.Abs(MoveH)+ Math.Abs(MoveV)))
                {
                    if (OFBH < 0 || OFBH > 20 || OFBV < 0|| OFBV > 20)
                    {
                        ActivityLog.Text += "You are attempting to move out of bounds\n\n";
                        ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    }
                    else
                    {
                        if (EnemyLocA[0] == CharLocA[0] + MoveH && EnemyLocA[1] == CharLocA[1] + MoveV)
                        {
                            if (EnemyLocA[0] == 0 || EnemyLocA[0] == 20)
                            {
                                CharLocA[1] += 1;
                            }
                            else if (EnemyLocA[1] == 0 || EnemyLocA[0] == 20)
                            { CharLocA[0] -= 1; }
                        }
                        else
                        {
                            if (AlphaButton.Text.Contains("Move"))
                            {
                                CharLocA[0] += MoveH;
                                CharLocA[1] += MoveV;
                                verticalDis = (EnemyLocA[1] - CharLocA[1]);
                                horizontalDis = (EnemyLocA[0] - CharLocA[0]);
                                distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horizontalDis * horizontalDis) + (verticalDis * verticalDis))));
                                ActivityLog.Text += "Your location is now (" + CharLocA[0] + "," + CharLocA[1] + ")\n\n";
                                ActivityLog.Text += "Distance is: " + distance + " \n\n";
                                ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                                
                                ActionSelect.Visible = true;
                                ActionSelect.Enabled = true;
                                ActSelect.Visible = true;
                                continueVariable = true;
                            }
                            AlphaButton.Text = "Action";
                        }

                        
                        if (ActionSelect.Items.Count <= 1)
                        {
                            AttackFill();
                            ActivityLog.Text += "As you can see you now have a set range. If you are outside of this range and still attempt to attack you will take the cost of attempting to attack.\n" +
                        "\n\nIf you attempt to heal and you lack the 30 mana it takes to cast the healing spell you lose any mana you had and the spell fails.\n" +
                        "If you lack the stats to attack or heal you can choose to \"Rest\" and gain some of it back slower than using a potion.\n\n ";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            AlphaButton.Text = "Action";
                        }
                        Horizontal.Text = "";
                        Vertical.Text = "";
                    }
                    if(continueVariable == true) { AlphaButton.Text = "Action"; } 

                }
                else { ActivityLog.Text += "Please enter usable numbers that are less than your total movement\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                

            }


            else if (AlphaButton.Text.Contains("Action"))
            {
                if (ActionSelect.Text.Length >= 0)
                {
                    
                    verticalDis = (EnemyLocA[1] - CharLocA[1]);
                    horizontalDis = (EnemyLocA[0] - CharLocA[0]);
                    distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horizontalDis * horizontalDis) + (verticalDis * verticalDis))));
                    ActivityLog.Text += "Distance is: " + distance + " \n\n";
                    
                    if (ActionSelect.Text.Length>1)
                    {
                        if (player.HP > 0 && villian.HP > 0)
                        {
                            verticalDis = (EnemyLocA[1] - CharLocA[1]);
                            horizontalDis = (EnemyLocA[0] - CharLocA[0]);
                            distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horizontalDis * horizontalDis) + (verticalDis * verticalDis))));
                            PlayerAttack(distance);
                            ActivityLog.Text += "The " + villian.type + " has "+villian.HP +" remaining. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;

                            Horizontal.Text = "";
                            Vertical.Text = "";
                            AlphaButton.Text = "Stay";
                            ActionSelect.Text = "";
                            if (villian.HP > 0 && player.HP >0)
                            {
                                //Enemy Stuff
                                
                                MoveEnemy(distance, verticalDis, horizontalDis);
                                verticalDis = (EnemyLocA[1] - CharLocA[1]);
                                horizontalDis = (EnemyLocA[0] - CharLocA[0]);
                                distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horizontalDis * horizontalDis) + (verticalDis * verticalDis))));
                                EnemyAttack(distance);
                            }
                            if (player.HP > 0 && villian.HP <= 0)
                            {
                                ActivityLog.Text += "The " + villian.type + " is dead. Good job! \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                                AlphaButton.Enabled = false;
                            }
                            else if (player.HP <= 0 && villian.HP > 0)
                            {
                                ActivityLog.Text += "The " + villian.type + " has killed you. I am disappointed. You must try harder next time. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                                AlphaButton.Enabled = false;
                            }

                        }
                        else if (player.HP > 0 && villian.HP <= 0)
                        {
                            ActivityLog.Text += "The " + villian.type + " is dead. Good job! \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            AlphaButton.Enabled = false;
                        }
                        else if (player.HP <= 0 && villian.HP > 0)
                        {
                            ActivityLog.Text += "The " + villian.type + " has killed you. I am disappointed. You must try harder next time. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            AlphaButton.Enabled = false;
                        }
                        else { ActivityLog.Text += "I broke Action attack\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                    }
                    else { ActivityLog.Text += "Please select an acceptable action.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
                    
                }
                else { ActivityLog.Text += "Please Select an attack.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;}
            }
            else { ActivityLog.Text += "WHYYY!!!\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;}
        }

        //Sets stats to the player class and prints them in the stat text boxes
        private Character StatSetter(Character player, int classNum)
        {
            //ActivityLog.Text += "StatSetter\n";
            //Barbarian
            if (classNum == 1)//barbarian
            {
                //They have high health, medium movement, low mana, medium armor, and medium stamina
                player.HP = 150 + (player.TankLevel(player.HP, player.Level));
                player.MP = 50 + (player.GeneralLevel(player.MP,  player.Level));
                player.SP = 100 + (player.GeneralLevel(player.SP,  player.Level));
                player.Mvmt = 100 / 15;
                player.ArmorClass = 10 + ((player.Level / 2) * 4);
                Health.Text = Convert.ToString(player.HP);
                Mana.Text = Convert.ToString(player.MP);
                Stamina.Text = Convert.ToString(player.SP);
                Movement.Text = Convert.ToString(player.Mvmt);
                Armor.Text = Convert.ToString(player.ArmorClass);

                player.Attack1.title = "Great Axe";
                player.Attack1.range = 1.5;
                player.Attack1.damage = 60 + player.AttackLevel(player.Attack1.damage, player.Level);
                player.Attack2.title = "Mow Down";
                player.Attack2.range = 1.5;
                player.Attack2.damage = 60 + player.AttackLevel(player.Attack1.damage, player.Level);
                player.Attack1.physical = true;
                player.Attack2.physical = true;

               
            }
            //Wizard
            else if (classNum == 2)//Wizard
            {
                //They have low health, low movement, super mana, no armor, and medium-low stamina.
                player.HP = 50 + (player.GeneralLevel(player.MP,  player.Level));
                player.MP = 200 + (player.WizLevel(player.MP, player.Level));
                player.SP = 75 + (player.GeneralLevel(player.SP,  player.Level));
                player.Mvmt = 75 / 15;
                player.ArmorClass = 0 + ((player.Level / 4) * 4);
                Health.Text = Convert.ToString(player.HP);
                Mana.Text = Convert.ToString(player.MP);
                Stamina.Text = Convert.ToString(player.SP);
                Movement.Text = Convert.ToString(player.Mvmt);
                Armor.Text = Convert.ToString(player.ArmorClass);



                player.Attack1.title = "Firebolt";
                player.Attack1.range = 7;
                player.Attack1.damage = 45 + player.AttackLevel(player.Attack1.damage, player.Level);
                player.Attack2.title = "Arctic Blast"; //extra damage and halves movement for game
                player.Attack2.range = 7;
                player.Attack1.physical = false;
                player.Attack2.physical = false;


            }
            //Archer
            else if (classNum == 3)//Archer
            {
                //They have low health, high movement, low mana, light armor, and high stamina.
                player.HP = 50 + (player.GeneralLevel(player.HP,  player.Level));
                player.MP = 50 + (player.GeneralLevel(player.MP,  player.Level));
                player.SP = 150 + (player.RunnerLevel(player.SP,  player.Level));
                player.Mvmt = 150 / 15;
                player.ArmorClass = 5 + ((player.Level / 2) * 4);
                Health.Text = Convert.ToString(player.HP);
                Mana.Text = Convert.ToString(player.MP);
                Stamina.Text = Convert.ToString(player.SP);
                Movement.Text = Convert.ToString(player.Mvmt);
                Armor.Text = Convert.ToString(player.ArmorClass);



                player.Attack1.title = "Single Arrow"; 
                player.Attack1.range = 9;
                player.Attack1.damage = 45 + player.AttackLevel(player.Attack1.damage, player.Level);
                player.Attack2.title = "Arrow Volley"; // between 2 and 5
                player.Attack1.range = 9;
                player.Attack1.physical = true;
                player.Attack2.physical = true;

            }
            //SwordsMen
            else if (classNum == 4)//SwordsMen
            {
                //They have medium-high health, high movement, low mana, high armor, and high stamina.
                player.HP = 125 + (player.GeneralLevel(player.HP,  player.Level));
                player.MP = 50 + (player.GeneralLevel(player.MP,  player.Level));
                player.SP = 150 + (player.RunnerLevel(player.SP,  player.Level));
                player.Mvmt = 150 / 15;
                player.ArmorClass = 15 + player.HighArmor(player.ArmorClass,player.Level);
                Health.Text = Convert.ToString(player.HP);
                Mana.Text = Convert.ToString(player.MP);
                Stamina.Text = Convert.ToString(player.SP);
                Movement.Text = Convert.ToString(player.Mvmt);
                Armor.Text = Convert.ToString(player.ArmorClass);




                player.Attack1.title = "Slash"; //basic strike
                player.Attack1.range = 1.5;
                player.Attack1.damage = 55 + player.AttackLevel(player.Attack1.damage, player.Level);
                player.Attack2.title = "Frenzy Strike"; //2 out of 5 chance to keep hitting until it fails
                player.Attack2.range = 1.5;
                player.Attack1.physical = true;
                player.Attack2.physical = true;

            }
            player.CharacterName = CharacterName.Text;
            Random rand = new Random();
            player.Potions = rand.Next(12)+3;
            PotionsCount.Text = Convert.ToString(player.Potions);
            Range.Text = Convert.ToString(player.Attack1.range);
            HPHolder = player.HP;
            MPHolder = player.MP;
            SPHolder = player.SP;
            return player;
        }

        private void AttackFill()
        {
            if (ClassSelect.Text.Contains("Barbarian"))
            { ActionSelect.Items.Add(""); ActionSelect.Items.Add("Basic Attack"); ActionSelect.Items.Add("Mow Down"); ActionSelect.Items.Add("Healing Spell"); ActionSelect.Items.Add("Potion"); ActionSelect.Items.Add("Rest"); }
            else if (ClassSelect.Text.Contains("Wizard"))
            { ActionSelect.Items.Add(""); ActionSelect.Items.Add("Basic Attack"); ActionSelect.Items.Add("Arctic Blast"); ActionSelect.Items.Add("Healing Spell"); ActionSelect.Items.Add("Potion"); ActionSelect.Items.Add("Rest"); }
            else if (ClassSelect.Text.Contains("Archer"))
            { ActionSelect.Items.Add(""); ActionSelect.Items.Add("Basic Attack"); ActionSelect.Items.Add("Arrow Volley"); ActionSelect.Items.Add("Healing Spell"); ActionSelect.Items.Add("Potion"); ActionSelect.Items.Add("Rest"); }
            else if (ClassSelect.Text.Contains("Swordsmen"))
            { ActionSelect.Items.Add(""); ActionSelect.Items.Add("Basic Attack"); ActionSelect.Items.Add("Frenzy Strike"); ActionSelect.Items.Add("Healing Spell"); ActionSelect.Items.Add("Potion"); ActionSelect.Items.Add("Rest"); }
        }

        private void MoveEnemy(int distance, int vertDis, int horiDis)
        {
            
            int tempmvmt=villian.Mvmt;
            bool mvmtcomplete = false;
            
            if (villian.Attack2.title != "") {

                if (distance > villian.Attack1.range || distance > villian.Attack2.range)
                {
                    //ActivityLog.Text += "Dual Attack\n\n";
                    while (mvmtcomplete = false || tempmvmt != 0) {
                        vertDis = (EnemyLocA[1] - CharLocA[1]);
                        horiDis = (EnemyLocA[0] - CharLocA[0]);
                        distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horiDis * horiDis) + (vertDis * vertDis))));
                        if (distance <= villian.Attack1.range )
                        {
                            mvmtcomplete = true;
                            ActivityLog.Text += "Enemy is within range.\n\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            break;
                        }
                        else if (CharLocA[0] < EnemyLocA[0])
                        {
                            EnemyLocA[0]--;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved left.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else if (CharLocA[0] > EnemyLocA[0])
                        {
                            EnemyLocA[0]++;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved right.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else if (CharLocA[1] < EnemyLocA[1])
                        {
                            EnemyLocA[1]--;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved down.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else if (CharLocA[1] > EnemyLocA[1])
                        {
                            EnemyLocA[1]++;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved up.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else
                        {
                            mvmtcomplete = true;
                            ActivityLog.Text += "Broke Enemy While Loop\n\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            break;
                        }
                    }
                }
            }
            else if (villian.Attack2.title== "") {
                //ActivityLog.Text += "Single Attack\n\n";
                if (distance > villian.Attack1.range)
                {
                    
                    while (mvmtcomplete = false || tempmvmt != 0)
                    {
                        
                        vertDis = (EnemyLocA[1] - CharLocA[1]);
                        horiDis = (EnemyLocA[0] - CharLocA[0]);
                        distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horiDis * horiDis) + (vertDis * vertDis))));
                       // ActivityLog.Text += "Distance is " + distance + "\n\n";
                        if (distance <= villian.Attack1.range)
                        {
                            mvmtcomplete = true;
                            ActivityLog.Text += "Enemy is within range.\n\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            break;
                        }
                        else if (CharLocA[0] < EnemyLocA[0])
                        {
                            EnemyLocA[0]--;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved left.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else if (CharLocA[0] > EnemyLocA[0])
                        {
                            EnemyLocA[0]++;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved right.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else if (CharLocA[1] < EnemyLocA[1])
                        {
                            EnemyLocA[1]--;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved down.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else if (CharLocA[1] > EnemyLocA[1])
                        {
                            EnemyLocA[1]++;
                            tempmvmt--;
                            ActivityLog.Text += "Enemy moved up.\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        }
                        else
                        {
                            ActivityLog.Text += "Broke Enemy While Loop\n\n";
                            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            mvmtcomplete = true;
                            break;
                        }
                        
                    }
                }
            }
            else
            {
                ActivityLog.Text += "I broke Move Enemy.";
            }
            ActivityLog.Text += "\nEnemy location is now (" + EnemyLocA[0] + "," + EnemyLocA[1] + ")\n\n";
            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            ActivityLog.Text += "You are at (" + CharLocA[0] + "," + CharLocA[1] + ")\n\n";
            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            vertDis = (EnemyLocA[1] - CharLocA[1]);
            horiDis = (EnemyLocA[0] - CharLocA[0]);
            distance = Convert.ToInt32(Math.Sqrt(Convert.ToDouble((horiDis * horiDis) + (vertDis * vertDis))));
            ActivityLog.Text += "Distance is: " + distance + " \n\n";
        }

        private Enemy BasicAttack(int stat, int distance)
        {
            if (player.Attack1.range >= distance)
            {
                if (player.Attack1.physical == true) {
                    ActivityLog.Text += "After attack SP "+Convert.ToString(player.SP - stat)+"\n\n";
                    if (0 <= (player.SP - stat))
                    {
                        villian.HP -= player.Attack1.damage;
                        player.SP = player.SP - stat;
                        Stamina.Text = Convert.ToString(player.SP);
                        ActivityLog.Text += "Stamina:  " + player.SP + "\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        ActivityLog.Text += "You dealt " + player.Attack1.damage + " damage. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    }
                    else if (0 > (player.SP - stat))
                    { ActivityLog.Text += "You tried to attack but failed and depleted your stamina.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; player.SP = 0; }
                    }
                else if (player.Attack1.physical == false)
                {
                    if (0 <= (player.MP - stat))
                    {
                        villian.HP -= player.Attack1.damage;
                        player.MP -= stat;
                        Mana.Text = Convert.ToString(player.MP);
                        ActivityLog.Text += "Mana:  " + player.MP + "\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        ActivityLog.Text += "You dealt " + player.Attack1.damage + " damage. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    }
                    else if (0 > (player.SP - stat))
                    { ActivityLog.Text += "You tried to attack but failed and depleted your Mana.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; player.MP = 0; }
                }
            
            }
            else if (player.Attack1.range < distance)
            {
                if (player.Attack1.physical == true)
                {
                    if (0 <= (player.SP - stat))
                    {
                        ActivityLog.Text += "Your attack missed becuase you are out of range.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        player.SP = player.SP - stat;
                        Stamina.Text = Convert.ToString(player.SP);
                        ActivityLog.Text += "Stamina:  " + player.SP + "\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    }
                    else if (0 > (player.SP - stat))
                    { ActivityLog.Text += "You tried to attack but failed and depleted your stamina.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; player.SP = 0; }
                }

                else if (player.Attack1.physical == false)
                {
                    if (0 <= (player.MP - stat))
                    { 
                        ActivityLog.Text += "Your attack missed becuase you are out of range.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        player.MP = player.MP - stat;
                        Mana.Text = Convert.ToString(player.MP);
                        ActivityLog.Text += "Mana:  " + player.MP + "\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    }
                }
            }

            else { ActivityLog.Text += "I broke at basic attack.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            
            if (countdown > 0) { countdown--; }
            return villian;
        }

        private void Potion()
        {
            ActivityLog.Text += "You drink a potion. You have "+player.Potions +" left.\n\n";
            ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;

            const int potionADD= 30;
            player.HP += potionADD;
            player.SP += potionADD;
            player.MP += potionADD;
            Mana.Text = Convert.ToString(player.MP);
            Health.Text = Convert.ToString(player.HP);
            Stamina.Text = Convert.ToString(player.SP);
            player.Potions--;
            PotionsCount.Text = Convert.ToString(player.Potions);
            if (countdown > 0) { countdown--; }
        }

        private void Heal()
        {
            if (player.MP >= 30)
            {
                if (HPHolder >= (player.HP + 30))
                {
                    ActivityLog.Text += "You used your healing spell.\n\n";
                    ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    player.MP -= 30;
                    player.HP += 40;
                    Mana.Text = Convert.ToString(player.MP);
                    Health.Text = Convert.ToString(player.HP);
                }
                else if (HPHolder<=(player.HP+30))
                { player.HP = HPHolder;
                    player.MP -= 30;
                }
            }
            else if (player.MP < 30)
            {
                ActivityLog.Text += "You try to cast your healing spell and since you lack the mana you fail and lose the mana you had.\n\n";
                player.MP = 0;
                Mana.Text = Convert.ToString(player.MP);
            }
            if (countdown > 0) { countdown--; }
        }

        //player attacks
        private Enemy PlayerAttack(int distance)
        {
            int stat=0;
            int specialstat = 0;
            if (ActionSelect.Text.Contains("Basic Attack"))
            {
                stat = 20 + (player.Level * 10);
                BasicAttack(stat, distance);
            }
            else if (ActionSelect.Text.Contains("Mow Down")|| ActionSelect.Text.Contains("Arctic Blast")|| ActionSelect.Text.Contains("Arrow Volley")|| ActionSelect.Text.Contains("Frenzy Strike"))
            {
                specialstat = (stat / 2);
                if (player.Attack2.range >= distance && countdown == 0)
                {
                    if (player.Attack2.title == "Mow Down")
                    {
                        ActivityLog.Text += "You spin your body slashing them 3 times.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        for (int counter = 3; counter > 0; counter--)
                        {
                            BasicAttack(specialstat, distance);
                        }
                        countdown = 3;
                    }
                    else if (player.Attack2.title == "Arctic Blast")
                    {
                        ActivityLog.Text += "You fire a blast of arctic air slowing your enemy. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        player.Attack2.damage = player.Attack1.damage * 2;
                        villian.Mvmt = villian.Mvmt / 2;
                        villian.HP -= player.Attack2.damage;
                        ActivityLog.Text += "You dealt " + player.Attack2.damage + " damage. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        countdown = 3;

                    }
                    else if (player.Attack2.title == "Arrow Volley")
                    {
                        ActivityLog.Text += "You launch a volley of arrows.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;

                        Random rand = new Random();
                        int Arrows = (rand.Next(4)) + 1;
                        ActivityLog.Text += "You launch a volley of " + Arrows + " arrows.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        villian.HP -= (player.Attack1.damage * Arrows);
                        ActivityLog.Text += "You dealt " + (player.Attack1.damage * Arrows) + " damage. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        countdown = 3;
                    }
                    else if (player.Attack2.title == "Frenzy Strike")
                    {
                        ActivityLog.Text += "You swing wildly.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        Random rand = new Random();
                        int looper = 55;
                        ActivityLog.Text += "Looper is " + looper + "\n\n";
                        while (looper <= 60)
                        {
                            BasicAttack(specialstat, distance);
                            rand = new Random();
                            looper = rand.Next(100);
                            ActivityLog.Text += "Looper is " + looper + "\n\n";
                        }
                        countdown = 3;

                    }
                    countdown = 3;
                }
                else if (player.Attack2.range < distance && countdown == 0)
                {
                    if (player.Attack2.title == "Mow Down")
                    {
                        ActivityLog.Text += "You spin your body slashing nothing but the air making yourself slightly dizzy.\n\n."; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;

                    }
                    else if (player.Attack2.title == "Arctic Blast")
                    {
                        ActivityLog.Text += "You fire a blast of arctic air at nothing.\n\n."; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                        player.Attack2.damage = player.Attack1.damage * 2;


                    }
                    else if (player.Attack2.title == "Arrow Volley")
                    {
                        ActivityLog.Text += "You launch a volley of arrows.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;

                        Random rand = new Random();
                        int Arrows = (rand.Next(4)) + 1;
                        ActivityLog.Text += "You launch a volley of " + Arrows + "arrows.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                    }
                    else if (player.Attack2.title == "Frenzy Strike")
                    {

                        Random rand = new Random();
                        int looper = rand.Next(100);
                        
                        while (looper <= 40)
                        {

                            ActivityLog.Text += "You swing wildly at nothing wasting your attack.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                            rand = new Random();
                            looper = rand.Next(100);
                           
                        }



                    }
                    countdown = 3;
                }
                else { ActivityLog.Text += "Your attack is still cooling down.\n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length; }
            }
            else if (ActionSelect.Text.Contains("Healing Spell")) { Heal(); }
            else if (ActionSelect.Text.Contains("Potion")) { Potion(); }
            else if (ActionSelect.Text.Contains("Rest")) {
                if (MPHolder >= (player.MP + 20)) { player.MP += 20;}
                else if (MPHolder< (player.MP + 20)) { player.MP = MPHolder; }
                if (SPHolder >= (player.SP + 20)) { player.SP += 20; }
                else if (SPHolder < (player.SP + 20)) { player.SP = SPHolder; }

            }
            else {
                ActivityLog.Text += "I broke Attack Enemy.\n\n";
                ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            }
            return villian;
        }

        //enemy attacks
        private void EnemyAttack(int distance)
        {
            if (villian.Attack1.range >= distance)
            {
                player.HP -= villian.Attack1.damage;
                Health.Text = Convert.ToString(player.HP);
                ActivityLog.Text += "The "+villian.type+ " attacked you with their "+villian.Attack1.title +" and dealt " + villian.Attack1.damage + " damage. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            }
            else if (villian.Attack2.range >= distance)
            {
                player.HP -= villian.Attack1.damage;
                Health.Text = Convert.ToString(player.HP);
                ActivityLog.Text += "The " + villian.type + " attacked you with their " + villian.Attack2.title + " and dealt " + villian.Attack2.damage + " damage. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;

            }
            else if ((villian.Attack1.range<distance)&&(villian.Attack2.range<distance))
            {
                ActivityLog.Text += "The enemy is out of range and can't attack this turn. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            }
            if (player.HP > 0 && villian.HP <= 0)
            {
                ActivityLog.Text += "The " + villian.type + " is dead. Good job! \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                AlphaButton.Enabled = false;
            }
            else if (player.HP <= 0 && villian.HP > 0)
            {
                ActivityLog.Text += "The " + villian.type + " has killed you. I am disappointed. You must try harder next time. \n\n"; ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
                AlphaButton.Enabled = false;
            }
        }

        private void EnemySet()
        {
            
            if (villian.type == "Dragon")
            {
                villian.HP = 250+villian.TankLevel(villian.HP,player.Level, villian.DM);
                villian.Attack1.title = "Bite";
                villian.Attack1.physical = true;
                villian.Attack1.range = 2;
                villian.Attack1.damage = 50 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Attack2.title = "Fire Breathe";
                villian.Attack2.range = 6;
                villian.Attack2.physical = false;
                villian.Attack1.damage = 35 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Mvmt = 6;
            }
            else if (villian.type == "Warlock")
            {
                villian.HP = 125+villian.GeneralLevel(villian.HP, player.Level, villian.DM);
                villian.Attack1.title = "Gaia Cannon";
                villian.Attack1.range = 6;
                villian.Attack1.physical = true;
                villian.Attack1.damage = 40 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Attack2.title = "Fireball";
                villian.Attack2.range = 7;
                villian.Attack2.physical = false;
                villian.Attack1.damage = 35 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Mvmt = 6;
            }
            else if (villian.type == "Goblin Leader")
            {
                villian.HP = 100 + villian.GeneralLevel(villian.HP, player.Level, villian.DM); ;
                villian.Attack1.title = "Dog Slicer";
                villian.Attack1.range = 1.5;
                villian.Attack1.physical = true;
                villian.Attack1.damage = 45 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Attack2.title = "";
                villian.Mvmt = 7;

            }
            else if (villian.type == "Serpant")
            {
                villian.HP = 175 + villian.GeneralLevel(villian.HP, player.Level, villian.DM); ;
                villian.Attack1.title = "Poison Bite";
                villian.Attack1.range = 2;
                villian.Attack1.damage = 49 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Attack1.physical = true;
                villian.Attack2.title = "";
                villian.Mvmt = 10;
            }
            else if (villian.type == "Bandit")
            {
                villian.HP = 150 + villian.TankLevel(villian.HP, player.Level, villian.DM); ;
                villian.Attack1.title = "Great Sword";
                villian.Attack1.range = 1.5;
                villian.Attack1.damage = 60 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Attack1.physical = true;
                villian.Attack2.title = "";
                villian.Mvmt = 5;
            }
            else if (villian.type == "Gelatinous Cube")
            {
                villian.HP = 200 + villian.GeneralLevel(villian.HP, player.Level, villian.DM); ;
                villian.Attack1.title = "Pseudopod";
                villian.Attack1.range = 1.5;
                villian.Attack1.damage = 40 + (villian.AttackLevel(villian.Attack1.damage, player.Level, villian.DM));
                villian.Attack1.physical = true;
                villian.Attack2.title = "";
                villian.Mvmt = 9;
            }
        }

        private int EnemyDifficultySetter(Enemy villian)
        {
            if (EnemyDifficulty.Text.Contains("Easy")) { villian.DM = 0; }
            else if (EnemyDifficulty.Text.Contains("Intermediate")) { villian.DM = 3; }
            else if (EnemyDifficulty.Text.Contains("Hard")) { villian.DM = 6; }
            else if (EnemyDifficulty.Text.Contains("Impossible")) { villian.DM = 12; }
            else if (EnemyDifficulty.Text.Contains("Good Luck")) { villian.DM = 24; }


            
                return villian.DM;
        }

        private void Horizontal_TextChanged(object sender, EventArgs e)
        {
            if (player.HP <= 0 || villian.HP <= 0) { }
            else
            {
                if (AlphaButton.Text == "Action") { }
                else
                {
                    if (Horizontal.Text.Length >= 1 || Vertical.Text.Length >= 1)
                    {
                        AlphaButton.Text = "Move";
                    }
                }
            }
        }

        private void Vertical_TextChanged(object sender, EventArgs e)
        {
            if (player.HP <= 0 || villian.HP <= 0) { }
            else
            {
                if (AlphaButton.Text == "Action")
                { }
                else
                {
                    if (Vertical.Text.Length >= 1 || Horizontal.Text.Length >= 1)
                    {
                        AlphaButton.Text = "Move";
                    }
                }
            }
        }

        private void ActionSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ActionSelect.Text.Contains("Healing Spell") && player.MP < 30)
            {
                ActivityLog.Text += "You lack the sufficent mana to cast this and if you try you will lose your action.\n\n";
            }
            if((ActionSelect.Text.Contains("Mow Down")|| ActionSelect.Text.Contains("Arctic Blast")|| ActionSelect.Text.Contains("Arrow Volley")|| ActionSelect.Text.Contains("Frenzy Strike") )&& countdown!=0)
            {
                ActivityLog.Text += "This Attack is still cooling down. If you attempt to use this you lose your attack. And the cool down is reset. There is still "+countdown+ " turns left.\n\n";
                ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            }
            else if(ActionSelect.Text.Contains("Mow Down") || ActionSelect.Text.Contains("Arctic Blast") || ActionSelect.Text.Contains("Arrow Volley") || ActionSelect.Text.Contains("Frenzy Strike") && countdown == 0)
            {
                ActivityLog.Text += "This Attack is your special attack. After you use it, it has a cooldown before you can use it again. But it is worth the wait\n\n";
                ActivityLog.Focus(); ActivityLog.SelectionStart = ActivityLog.Text.Length;
            }
        }

        
    }

}

