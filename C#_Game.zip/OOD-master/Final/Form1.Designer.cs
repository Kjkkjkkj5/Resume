﻿namespace Final
{
    partial class OOD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ClassSelect = new System.Windows.Forms.ComboBox();
            this.CharacterName = new System.Windows.Forms.TextBox();
            this.LevelControl = new System.Windows.Forms.NumericUpDown();
            this.Level = new System.Windows.Forms.Label();
            this.Health = new System.Windows.Forms.TextBox();
            this.Mana = new System.Windows.Forms.TextBox();
            this.Stamina = new System.Windows.Forms.TextBox();
            this.HealthPoints = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Armor = new System.Windows.Forms.TextBox();
            this.Movement = new System.Windows.Forms.TextBox();
            this.PotionsCount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.LevelTip = new System.Windows.Forms.ToolTip(this.components);
            this.ClassTip = new System.Windows.Forms.ToolTip(this.components);
            this.WontWriteTip = new System.Windows.Forms.ToolTip(this.components);
            this.SuperButton = new System.Windows.Forms.Button();
            this.ActivityLog = new System.Windows.Forms.RichTextBox();
            this.EnemySelect = new System.Windows.Forms.ComboBox();
            this.DiffLabel = new System.Windows.Forms.Label();
            this.EnemyLabel = new System.Windows.Forms.Label();
            this.EnemyDifficulty = new System.Windows.Forms.ComboBox();
            this.AlphaButton = new System.Windows.Forms.Button();
            this.Horizontal = new System.Windows.Forms.TextBox();
            this.Vertical = new System.Windows.Forms.TextBox();
            this.Hori = new System.Windows.Forms.Label();
            this.Vert = new System.Windows.Forms.Label();
            this.ActionSelect = new System.Windows.Forms.ComboBox();
            this.ActSelect = new System.Windows.Forms.Label();
            this.Range = new System.Windows.Forms.TextBox();
            this.RangeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.LevelControl)).BeginInit();
            this.SuspendLayout();
            // 
            // ClassSelect
            // 
            this.ClassSelect.AllowDrop = true;
            this.ClassSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ClassSelect.DropDownWidth = 60;
            this.ClassSelect.FormattingEnabled = true;
            this.ClassSelect.Items.AddRange(new object[] {
            "Barbarian",
            "Wizard",
            "Archer",
            "Swordsmen"});
            this.ClassSelect.Location = new System.Drawing.Point(192, 31);
            this.ClassSelect.Margin = new System.Windows.Forms.Padding(4);
            this.ClassSelect.Name = "ClassSelect";
            this.ClassSelect.Size = new System.Drawing.Size(164, 24);
            this.ClassSelect.TabIndex = 0;
            this.ClassTip.SetToolTip(this.ClassSelect, "This is used to select your class. Each class has its own pros and cons so choose" +
        " wisely.\r\n");
            this.ClassSelect.SelectedIndexChanged += new System.EventHandler(this.ClassSelect_SelectedIndexChanged);
            // 
            // CharacterName
            // 
            this.CharacterName.Location = new System.Drawing.Point(21, 31);
            this.CharacterName.Name = "CharacterName";
            this.CharacterName.Size = new System.Drawing.Size(165, 22);
            this.CharacterName.TabIndex = 1;
            // 
            // LevelControl
            // 
            this.LevelControl.Location = new System.Drawing.Point(363, 31);
            this.LevelControl.Name = "LevelControl";
            this.LevelControl.Size = new System.Drawing.Size(78, 22);
            this.LevelControl.TabIndex = 2;
            this.LevelTip.SetToolTip(this.LevelControl, "This box must be between 1-100\r\n");
            // 
            // Level
            // 
            this.Level.AutoSize = true;
            this.Level.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Level.Location = new System.Drawing.Point(360, 9);
            this.Level.Name = "Level";
            this.Level.Size = new System.Drawing.Size(49, 20);
            this.Level.TabIndex = 3;
            this.Level.Text = "Level";
            // 
            // Health
            // 
            this.Health.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Health.Enabled = false;
            this.Health.Location = new System.Drawing.Point(21, 86);
            this.Health.Name = "Health";
            this.Health.Size = new System.Drawing.Size(79, 22);
            this.Health.TabIndex = 4;
            this.WontWriteTip.SetToolTip(this.Health, "This is auto-generated.");
            // 
            // Mana
            // 
            this.Mana.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Mana.Enabled = false;
            this.Mana.Location = new System.Drawing.Point(107, 86);
            this.Mana.Name = "Mana";
            this.Mana.Size = new System.Drawing.Size(79, 22);
            this.Mana.TabIndex = 5;
            this.WontWriteTip.SetToolTip(this.Mana, "This is auto-generated.");
            // 
            // Stamina
            // 
            this.Stamina.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Stamina.Enabled = false;
            this.Stamina.Location = new System.Drawing.Point(202, 86);
            this.Stamina.Name = "Stamina";
            this.Stamina.Size = new System.Drawing.Size(79, 22);
            this.Stamina.TabIndex = 6;
            this.WontWriteTip.SetToolTip(this.Stamina, "This is auto-generated.");
            // 
            // HealthPoints
            // 
            this.HealthPoints.AutoSize = true;
            this.HealthPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HealthPoints.Location = new System.Drawing.Point(18, 66);
            this.HealthPoints.Name = "HealthPoints";
            this.HealthPoints.Size = new System.Drawing.Size(64, 20);
            this.HealthPoints.TabIndex = 7;
            this.HealthPoints.Text = "Health*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(104, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Mana*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(195, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Stamina*";
            // 
            // label3
            // 
            this.label3.AutoEllipsis = true;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 499);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(755, 29);
            this.label3.TabIndex = 10;
            this.label3.Text = "* These items are filled in by computer after your character is filled out";
            // 
            // Armor
            // 
            this.Armor.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Armor.Enabled = false;
            this.Armor.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Armor.Location = new System.Drawing.Point(376, 86);
            this.Armor.Name = "Armor";
            this.Armor.Size = new System.Drawing.Size(79, 22);
            this.Armor.TabIndex = 11;
            this.WontWriteTip.SetToolTip(this.Armor, "This is auto-generated.");
            // 
            // Movement
            // 
            this.Movement.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Movement.Enabled = false;
            this.Movement.Location = new System.Drawing.Point(287, 86);
            this.Movement.Name = "Movement";
            this.Movement.Size = new System.Drawing.Size(79, 22);
            this.Movement.TabIndex = 12;
            this.WontWriteTip.SetToolTip(this.Movement, "This is auto-generated.");
            // 
            // PotionsCount
            // 
            this.PotionsCount.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PotionsCount.Enabled = false;
            this.PotionsCount.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.PotionsCount.Location = new System.Drawing.Point(461, 86);
            this.PotionsCount.Name = "PotionsCount";
            this.PotionsCount.Size = new System.Drawing.Size(79, 22);
            this.PotionsCount.TabIndex = 13;
            this.WontWriteTip.SetToolTip(this.PotionsCount, "This is auto-generated.");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(455, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Potions*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(372, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Armor*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(274, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Movement*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(189, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "Class";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 20);
            this.label8.TabIndex = 18;
            this.label8.Text = "Name";
            // 
            // LevelTip
            // 
            this.LevelTip.Tag = "";
            // 
            // SuperButton
            // 
            this.SuperButton.Location = new System.Drawing.Point(376, 123);
            this.SuperButton.Name = "SuperButton";
            this.SuperButton.Size = new System.Drawing.Size(164, 53);
            this.SuperButton.TabIndex = 21;
            this.SuperButton.Text = "Create Character";
            this.SuperButton.UseVisualStyleBackColor = true;
            this.SuperButton.Click += new System.EventHandler(this.SuperButton_Click);
            // 
            // ActivityLog
            // 
            this.ActivityLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ActivityLog.Location = new System.Drawing.Point(546, 12);
            this.ActivityLog.Name = "ActivityLog";
            this.ActivityLog.ReadOnly = true;
            this.ActivityLog.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical;
            this.ActivityLog.Size = new System.Drawing.Size(271, 484);
            this.ActivityLog.TabIndex = 20;
            this.ActivityLog.TabStop = false;
            this.ActivityLog.Text = "Hello! Welcome to Objective Oriented Destruction!\n\nPlease enter your name, class " +
    "and level and we will get started.\n\n";
            // 
            // EnemySelect
            // 
            this.EnemySelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnemySelect.FormattingEnabled = true;
            this.EnemySelect.Items.AddRange(new object[] {
            "Dragon",
            "Warlock",
            "Goblin Leader",
            "Serpant",
            "Bandit",
            "Gelatinous Cube"});
            this.EnemySelect.Location = new System.Drawing.Point(21, 138);
            this.EnemySelect.Name = "EnemySelect";
            this.EnemySelect.Size = new System.Drawing.Size(165, 24);
            this.EnemySelect.TabIndex = 22;
            this.EnemySelect.SelectedIndexChanged += new System.EventHandler(this.EnemySelect_SelectedIndexChanged);
            // 
            // DiffLabel
            // 
            this.DiffLabel.AutoSize = true;
            this.DiffLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiffLabel.Location = new System.Drawing.Point(189, 118);
            this.DiffLabel.Name = "DiffLabel";
            this.DiffLabel.Size = new System.Drawing.Size(75, 20);
            this.DiffLabel.TabIndex = 23;
            this.DiffLabel.Text = "Difficulty";
            // 
            // EnemyLabel
            // 
            this.EnemyLabel.AutoSize = true;
            this.EnemyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnemyLabel.Location = new System.Drawing.Point(17, 111);
            this.EnemyLabel.Name = "EnemyLabel";
            this.EnemyLabel.Size = new System.Drawing.Size(112, 20);
            this.EnemyLabel.TabIndex = 24;
            this.EnemyLabel.Text = "Enemy Select";
            // 
            // EnemyDifficulty
            // 
            this.EnemyDifficulty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EnemyDifficulty.FormattingEnabled = true;
            this.EnemyDifficulty.Items.AddRange(new object[] {
            "Easy",
            "Intermediate",
            "Hard",
            "Impossible",
            "Good Luck"});
            this.EnemyDifficulty.Location = new System.Drawing.Point(192, 138);
            this.EnemyDifficulty.Name = "EnemyDifficulty";
            this.EnemyDifficulty.Size = new System.Drawing.Size(164, 24);
            this.EnemyDifficulty.TabIndex = 25;
            this.EnemyDifficulty.SelectedIndexChanged += new System.EventHandler(this.EnemyDifficulty_SelectedIndexChanged);
            // 
            // AlphaButton
            // 
            this.AlphaButton.Enabled = false;
            this.AlphaButton.Location = new System.Drawing.Point(376, 124);
            this.AlphaButton.Name = "AlphaButton";
            this.AlphaButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.AlphaButton.Size = new System.Drawing.Size(164, 52);
            this.AlphaButton.TabIndex = 26;
            this.AlphaButton.Text = "Stay";
            this.AlphaButton.UseVisualStyleBackColor = true;
            this.AlphaButton.Visible = false;
            this.AlphaButton.Click += new System.EventHandler(this.AlphaButton_Click);
            // 
            // Horizontal
            // 
            this.Horizontal.Enabled = false;
            this.Horizontal.Location = new System.Drawing.Point(24, 189);
            this.Horizontal.Name = "Horizontal";
            this.Horizontal.Size = new System.Drawing.Size(69, 22);
            this.Horizontal.TabIndex = 27;
            this.Horizontal.Visible = false;
            this.Horizontal.TextChanged += new System.EventHandler(this.Horizontal_TextChanged);
            // 
            // Vertical
            // 
            this.Vertical.Location = new System.Drawing.Point(113, 189);
            this.Vertical.Name = "Vertical";
            this.Vertical.Size = new System.Drawing.Size(52, 22);
            this.Vertical.TabIndex = 28;
            this.Vertical.Visible = false;
            this.Vertical.TextChanged += new System.EventHandler(this.Vertical_TextChanged);
            // 
            // Hori
            // 
            this.Hori.AutoSize = true;
            this.Hori.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hori.Location = new System.Drawing.Point(17, 169);
            this.Hori.Name = "Hori";
            this.Hori.Size = new System.Drawing.Size(86, 20);
            this.Hori.TabIndex = 29;
            this.Hori.Text = "Horizontal";
            this.Hori.Visible = false;
            // 
            // Vert
            // 
            this.Vert.AutoSize = true;
            this.Vert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vert.Location = new System.Drawing.Point(109, 169);
            this.Vert.Name = "Vert";
            this.Vert.Size = new System.Drawing.Size(66, 20);
            this.Vert.TabIndex = 30;
            this.Vert.Text = "Vertical";
            this.Vert.Visible = false;
            // 
            // ActionSelect
            // 
            this.ActionSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ActionSelect.Enabled = false;
            this.ActionSelect.FormattingEnabled = true;
            this.ActionSelect.Location = new System.Drawing.Point(185, 189);
            this.ActionSelect.Name = "ActionSelect";
            this.ActionSelect.Size = new System.Drawing.Size(170, 24);
            this.ActionSelect.TabIndex = 31;
            this.ActionSelect.Visible = false;
            this.ActionSelect.SelectedIndexChanged += new System.EventHandler(this.ActionSelect_SelectedIndexChanged);
            // 
            // ActSelect
            // 
            this.ActSelect.AutoSize = true;
            this.ActSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ActSelect.Location = new System.Drawing.Point(189, 169);
            this.ActSelect.Name = "ActSelect";
            this.ActSelect.Size = new System.Drawing.Size(108, 20);
            this.ActSelect.TabIndex = 32;
            this.ActSelect.Text = "Action Select";
            this.ActSelect.Visible = false;
            // 
            // Range
            // 
            this.Range.Enabled = false;
            this.Range.Location = new System.Drawing.Point(447, 30);
            this.Range.Name = "Range";
            this.Range.ReadOnly = true;
            this.Range.Size = new System.Drawing.Size(79, 22);
            this.Range.TabIndex = 33;
            // 
            // RangeLabel
            // 
            this.RangeLabel.AutoSize = true;
            this.RangeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RangeLabel.Location = new System.Drawing.Point(443, 7);
            this.RangeLabel.Name = "RangeLabel";
            this.RangeLabel.Size = new System.Drawing.Size(63, 20);
            this.RangeLabel.TabIndex = 34;
            this.RangeLabel.Text = "Range*";
            // 
            // OOD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 537);
            this.Controls.Add(this.Vert);
            this.Controls.Add(this.Health);
            this.Controls.Add(this.Mana);
            this.Controls.Add(this.Stamina);
            this.Controls.Add(this.Movement);
            this.Controls.Add(this.PotionsCount);
            this.Controls.Add(this.Armor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.RangeLabel);
            this.Controls.Add(this.Range);
            this.Controls.Add(this.ActSelect);
            this.Controls.Add(this.ActionSelect);
            this.Controls.Add(this.Hori);
            this.Controls.Add(this.Vertical);
            this.Controls.Add(this.Horizontal);
            this.Controls.Add(this.AlphaButton);
            this.Controls.Add(this.EnemyDifficulty);
            this.Controls.Add(this.EnemyLabel);
            this.Controls.Add(this.DiffLabel);
            this.Controls.Add(this.EnemySelect);
            this.Controls.Add(this.SuperButton);
            this.Controls.Add(this.ActivityLog);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HealthPoints);
            this.Controls.Add(this.Level);
            this.Controls.Add(this.LevelControl);
            this.Controls.Add(this.CharacterName);
            this.Controls.Add(this.ClassSelect);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "OOD";
            this.Text = "Objective Oriented Destruction";
            this.WontWriteTip.SetToolTip(this, "This is auto-generated.");
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.LevelControl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ClassSelect;
        private System.Windows.Forms.TextBox CharacterName;
        public System.Windows.Forms.NumericUpDown LevelControl;
        private System.Windows.Forms.Label Level;
        private System.Windows.Forms.TextBox Health;
        private System.Windows.Forms.TextBox Mana;
        private System.Windows.Forms.TextBox Stamina;
        private System.Windows.Forms.Label HealthPoints;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Armor;
        private System.Windows.Forms.TextBox Movement;
        private System.Windows.Forms.TextBox PotionsCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ToolTip LevelTip;
        private System.Windows.Forms.ToolTip ClassTip;
        private System.Windows.Forms.ToolTip WontWriteTip;
        private System.Windows.Forms.Button SuperButton;
        private System.Windows.Forms.RichTextBox ActivityLog;
        private System.Windows.Forms.ComboBox EnemySelect;
        private System.Windows.Forms.Label DiffLabel;
        private System.Windows.Forms.Label EnemyLabel;
        private System.Windows.Forms.ComboBox EnemyDifficulty;
        private System.Windows.Forms.Button AlphaButton;
        private System.Windows.Forms.TextBox Horizontal;
        private System.Windows.Forms.TextBox Vertical;
        private System.Windows.Forms.Label Hori;
        private System.Windows.Forms.Label Vert;
        private System.Windows.Forms.ComboBox ActionSelect;
        private System.Windows.Forms.Label ActSelect;
        private System.Windows.Forms.TextBox Range;
        private System.Windows.Forms.Label RangeLabel;
    }
}

